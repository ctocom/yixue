<template>
</template>

<script> 
const userApi="http://api.yixueyouke.net/index";
// const  userTp5= "http://tp5.abc.com/index"; 
  export default
  {
    // userTp5,//用户地址
    userApi, 
  }
	
	
</script>


<style>
	
</style>