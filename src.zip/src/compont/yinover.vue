<template>
	<div class="yin_max"> 
		<div class="yinCon">
			<div class="yin_img">
				<img src="" alt="">123
			</div>
			<div class="yinTet">
				123
				<button>
					打印
				</button>
			</div>
		</div>
	</div>
</template>

<script>
</script>

<style>
	@media screen and (max-width: 980px) {
		.yinCon{
			width: 90%;
			height: 60px;
			margin: 0 auto;
		}
		 .yin_img{
			 width: 30px;
			 height: 100%; 
			 float: left;
			 background-color: #008B8B;
		 }
		 .yinTet{
			 height: 100%;
			 background-color: grey;
		 }
		 .button button{
			 width: 20px;
			 height: 10px;
			 border: 1px solid black;
		 }
	}
</style>
